import reflex as rx

config = rx.Config( app_name="Web_Union_componentes")